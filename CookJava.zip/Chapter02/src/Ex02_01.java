
public class Ex02_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a, b;
		int result;

		a = 100;
		b = 50;

		result = a + b;
		System.out.println(a + "+" + b + "=" + result);

		result = a - b;
		System.out.println(a + "-" + b + "=" + result);

		result = a * b;
		System.out.println(a + "*" + b + "=" + result);

		result = a / b;
		System.out.println(a + "/" + b + "=" + result);

	}

}
