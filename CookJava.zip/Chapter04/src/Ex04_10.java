public class Ex04_10 {
	public static void main(String[] args) {
		System.out.printf(" 10 ^ 7 = %d \n", 10 ^ 7);
		System.out.printf(" 123 ^ 456 = %d \n", 123 ^ 456);
		System.out.printf(" 0xFFFF ^ 0000 = %d \n",  0xFFFF ^ 0000);
	}
}
