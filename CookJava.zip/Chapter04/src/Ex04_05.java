public class Ex04_05 {
	public static void main(String[] args) {
		int a = 100, b = 200;

		System.out.printf(" %d  == %d ��   %s  �̴�.\n", a, b, a == b);
		System.out.printf(" %d  != %d ��   %s  �̴�.\n", a, b, a != b);
		System.out.printf(" %d  >  %d ��   %s  �̴�.\n", a, b, a > b);
		System.out.printf(" %d  <  %d ��   %s  �̴�.\n", a, b, a < b);
		System.out.printf(" %d  >= %d ��   %s  �̴�.\n", a, b, a >= b);
		System.out.printf(" %d  <= %d ��   %s  �̴�.\n", a, b, a <= b);

		System.out.printf(" %d  =  %d ��   %s  �̴�.\n", a, b, a = b);
	}
}
