/*
abstract class Car {
	int speed = 0;
	String color;

	void upSpeed(int speed) {
		this.speed += speed;		
	}	
}

class Sedan extends Car {
}

class Truck extends Car {
}

public class Ex12_08 {
	public static void main(String[] args) {

		// Car car1 = new Car();
		Sedan sedan1 = new Sedan();
		System.out.println("�¿��� �ν��Ͻ� ����~~~");
		Truck truck1 = new Truck();		
		System.out.println("Ʈ�� �ν��Ͻ� ����~~~");
	}
}
*/
