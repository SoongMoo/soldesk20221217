/*
class Car {
	protected String color;
	int speed;
}

class Sedan extends Car {
	void setSpeed(int speed) {
		this.speed = speed;
	}

	void setColor(String color) {
		 this.color = color;
	}
}

public class Ex12_05 {
	public static void main(String[] args) {

		Sedan sedan1 = new Sedan();

		sedan1.setSpeed(300);
		sedan1.setColor("����");
		System.out.println("�¿��� �ӵ� ==> " + sedan1.speed);
		System.out.println("�¿��� ���� ==> " + sedan1.color);
		
		Car mycar1 = new Car();
		mycar1.color = "red";
	}
}
*/
