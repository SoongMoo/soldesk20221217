public class Ex06_16 {
	public static void main(String[] args) {
		int i, k;

		for (i = 1, k = 1; i <= 9; i++, k++)
			System.out.printf(" %d X %d = %d \n", i, k, i * k);

	}
}