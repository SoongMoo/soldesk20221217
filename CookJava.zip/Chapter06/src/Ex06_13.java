public class Ex06_13 {
	public static void main(String[] args) {
		int i, k;

		for (i = 0; i < 3; i++) 
		{
			for (k = 0; k < 2; k++) 
			{
				System.out.printf("��ø for ���Դϴ�. (i��: %d, k��: %d)\n", i, k);
			}
		}
		
	}
}