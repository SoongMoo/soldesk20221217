public class Ex03_07 {
	public static void main(String[] args) {
		int a;
		float b;

		a = (int) 123.45f;
		b = 200;

		System.out.printf("a�� �� ==> %d \n", a);
		System.out.printf("b�� �� ==> %f \n", b);
	}
}
