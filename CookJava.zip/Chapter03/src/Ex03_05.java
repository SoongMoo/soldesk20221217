public class Ex03_05 {
	public static void main(String[] args) {
		System.out.printf("%d\n", 123);
		System.out.printf("%5d\n", 123);
		System.out.printf("%05d\n", 123);

		System.out.printf("%f\n", 123.45);
		System.out.printf("%7.1f\n", 123.45);
		System.out.printf("%7.3f\n", 123.45);

		System.out.printf("%s\n", "Hi~Java");
		System.out.printf("%10s\n", "Hi~Java");
	}
}
