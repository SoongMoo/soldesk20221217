public class Ex03_02 {
	public static void main(String[] args) {
		System.out.printf("%d", 100, 200);
		System.out.printf("\n");
		System.out.printf("%d  %d", 100);
		System.out.printf("\n");
	}
}
