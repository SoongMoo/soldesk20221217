public class Ex03_14 {
	public static void main(String[] args) {
		boolean boo1, boo2;

		boo1 = true;
		System.out.printf("%s \n", boo1);

		boo2 = (10 == 20);
		System.out.printf("%s \n", boo2);
	}
}