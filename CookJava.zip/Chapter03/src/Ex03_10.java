public class Ex03_10 {
	public static void main(String[] args) {
		   int a=100, b=200;
		   float result;
		
		   result = a / b;
		   
		   System.out.printf ("%f  \n", result);   
	}
}