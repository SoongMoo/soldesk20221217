public class Ex03_15 {
	public static void main(String[] args) {
		String str1 = "IT CookBook �Դϴ�.";
		String str2 = "10";
		String str3 = "20";

		str1 = "Java �Դϴ�. ";

		System.out.printf("%s \n", str1);
		System.out.printf("%s \n", str2 + str3);
	}
}