public class Ex09_01 {
	public static void main(String[] args) {
		String str = "IT CookBook. Java";
		int len;

		len = str.length();

		System.out.printf("���ڿ�  : %s \n", str);
		System.out.printf("���ڿ� ���� : %d ", len);
		
		
	}
}
